All files in src:
- Client.java
- GameState.java
- Host.java
- Server.java
- UML.pdf

How to compile:
1. run Server main method
2. run Host main method
3. run Client main method
4. in Client console input player name and you should be able to cycle through all the states there.

**did not have enough time to finish sequence diagram and clear up all code duplication.